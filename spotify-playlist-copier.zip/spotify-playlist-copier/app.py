from flask import Flask, render_template, request, jsonify
import spotipy
from spotipy.oauth2 import SpotifyOAuth
import config

app = Flask(__name__)

# Spotify bağlantısını kur
sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
    client_id=config.SPOTIPY_CLIENT_ID,
    client_secret=config.SPOTIPY_CLIENT_SECRET,
    redirect_uri=config.SPOTIPY_REDIRECT_URI,
    scope="playlist-read-private playlist-modify-public playlist-modify-private"
))

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/clone', methods=['POST'])
def clone_playlist():
    try:
        data = request.get_json()
        playlist_url = data['playlist_url']
        
        # Playlist ID'sini çıkar
        playlist_id = playlist_url.split("/")[-1].split("?")[0]
        
        # Playlist bilgilerini al
        playlist = sp.playlist(playlist_id)
        playlist_name = playlist['name']
        total_tracks = playlist['tracks']['total']
        
        # Tüm şarkıları al
        tracks = []
        results = sp.playlist_tracks(playlist_id)
        tracks.extend(results['items'])
        
        while results['next']:
            results = sp.next(results)
            tracks.extend(results['items'])
        
        # Şarkı URI'larını topla
        track_uris = []
        for item in tracks:
            if item['track']:
                track_uris.append(item['track']['uri'])
        
        # Yeni playlist oluştur
        new_playlist_name = f"{playlist_name} (Kopya)"
        user_id = sp.current_user()['id']
        new_playlist = sp.user_playlist_create(user_id, new_playlist_name, public=True)
        
        # Şarkıları ekle
        for i in range(0, len(track_uris), 100):
            sp.playlist_add_items(new_playlist['id'], track_uris[i:i+100])
        
        return jsonify({
            'success': True,
            'original_name': playlist_name,
            'new_name': new_playlist_name,
            'total_tracks': len(track_uris),
            'playlist_url': new_playlist['external_urls']['spotify']
        })
        
    except Exception as e:
        return jsonify({
            'success': False,
            'error': str(e)
        })

if __name__ == '__main__':
    app.run(debug=True)
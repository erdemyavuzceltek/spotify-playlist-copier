import spotipy
from spotipy.oauth2 import SpotifyOAuth
import config

# Spotify bağlantısını kur
sp = spotipy.Spotify(auth_manager=SpotifyOAuth(
    client_id=config.SPOTIPY_CLIENT_ID,
    client_secret=config.SPOTIPY_CLIENT_SECRET,
    redirect_uri=config.SPOTIPY_REDIRECT_URI,
    scope="playlist-read-private playlist-modify-public playlist-modify-private"
))

print("=== Spotify Playlist Klonlayıcı ===\n")

# Kullanıcıdan playlist linki al
playlist_url = input("Klonlamak istediğiniz playlist linkini girin: ")

# Playlist ID'sini çıkar
playlist_id = playlist_url.split("/")[-1].split("?")[0]

# Playlist bilgilerini al
print("\nPlaylist bilgileri alınıyor...")
playlist = sp.playlist(playlist_id)
playlist_name = playlist['name']
print(f"Playlist: {playlist_name}")
print(f"Toplam şarkı: {playlist['tracks']['total']}")

# Tüm şarkıları al
print("\nŞarkılar alınıyor...")
tracks = []
results = sp.playlist_tracks(playlist_id)
tracks.extend(results['items'])

while results['next']:
    results = sp.next(results)
    tracks.extend(results['items'])

# Şarkı URI'larını topla
track_uris = []
for item in tracks:
    if item['track']:
        track_uris.append(item['track']['uri'])

print(f"{len(track_uris)} şarkı bulundu!")

# Yeni playlist oluştur
new_playlist_name = f"{playlist_name} (Kopya)"
print(f"\nYeni playlist oluşturuluyor: {new_playlist_name}")
user_id = sp.current_user()['id']
new_playlist = sp.user_playlist_create(user_id, new_playlist_name, public=True)

# Şarkıları yeni playliste ekle
print("Şarkılar ekleniyor...")
for i in range(0, len(track_uris), 100):
    sp.playlist_add_items(new_playlist['id'], track_uris[i:i+100])

print(f"\n✅ Başarılı! '{new_playlist_name}' oluşturuldu!")
print(f"Link: {new_playlist['external_urls']['spotify']}")
# 🎵 Spotify Playlist Cloner

![Spotify](https://img.shields.io/badge/Spotify-1DB954?style=for-the-badge&logo=spotify&logoColor=white)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![Flask](https://img.shields.io/badge/Flask-000000?style=for-the-badge&logo=flask&logoColor=white)

A modern web application that allows you to clone any public Spotify playlist to your own library with just one click!

## 📋 Table of Contents
- [Features](#-features)
- [Demo](#-demo)
- [Technologies](#-technologies)
- [Installation](#-installation)
- [Usage](#-usage)
- [Configuration](#-configuration)
- [Project Structure](#-project-structure)
- [Contributing](#-contributing)
- [License](#-license)

## ✨ Features

-  **Clone Any Public Playlist**: Copy songs from any public Spotify playlist
-  **Fast & Efficient**: Handles playlists with hundreds of songs seamlessly
-  **Modern UI**: Clean, user-friendly web interface with Spotify-inspired design
-  **Secure**: Uses official Spotify OAuth 2.0 authentication
-  **Responsive**: Works perfectly on desktop and mobile devices
-  **Real-time Feedback**: Shows progress and results instantly



## 🛠 Technologies

This project is built with:

- **Backend**: Python 3.x, Flask
- **Frontend**: HTML5, CSS3, JavaScript (Vanilla)
- **API**: Spotify Web API
- **Authentication**: OAuth 2.0 (via Spotipy)
- **HTTP Client**: Requests library

## 📦 Installation

### Prerequisites

- Python 3.7 or higher
- A Spotify account
- Git (optional, for cloning)

